# README #

This repository contains an NSF project template, in LaTeX.  It includes a Makefile as well as classes for the proposal itself as well as NSF-compatible CVs.

### Files ###

* Skeleton for project summary, description, data management plan
* Skeleton for budget justification
* Boilerplate for UCSC facilities

### Who do I talk to? ###

* Managed by: Ethan Miller (elm@ucsc.edu) and Darrell Long (darrell@ucsc.edu
* Also see the CRSS web site: http://www.crss.ucsc.edu/